from __future__ import annotations

from typing import Any


class ConnectorError(Exception):
    def __init__(self, code: str, message: str, details: dict[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details


def _as_int(props: dict[str, str], key: str, default: int) -> int:
    raw = (props.get(key) or "").strip()
    if not raw:
        return default
    try:
        return int(raw)
    except Exception:
        raise ConnectorError("INVALID_CONFIG", f"Invalid number for {key}.", {"key": key})


def _connect(props: dict[str, str], secret_resolver):
    host = (props.get("host") or "").strip()
    port = _as_int(props, "port", 1521)
    service_name = (props.get("serviceName") or "").strip()
    username = (props.get("username") or "").strip()
    password = secret_resolver.resolve(key="password", value=props.get("password") or "")

    if not host or not service_name or not username or not password:
        raise ConnectorError("INVALID_CONFIG", "Missing required fields.", None)

    try:
        import oracledb  # type: ignore
    except Exception as e:
        raise ConnectorError("MISSING_DEPENDENCY", "Oracle connector dependency is missing (oracledb).", {"error": str(e)})

    try:
        dsn = oracledb.makedsn(host, port, service_name=service_name)
        return oracledb.connect(user=username, password=password, dsn=dsn)
    except Exception as e:
        msg = str(e).lower()
        if "ora-01017" in msg or "invalid username/password" in msg:
            raise ConnectorError("AUTH_FAILED", "Authentication failed.", {"error": str(e)})
        raise ConnectorError("NETWORK", "Oracle connection failed.", {"error": str(e)})


def test_connection(props: dict[str, str], secret_resolver) -> None:
    with _connect(props, secret_resolver) as conn:
        cur = conn.cursor()
        cur.execute("SELECT 1 FROM DUAL")
        _ = cur.fetchone()


def list_schemas(props: dict[str, str], secret_resolver) -> list[str]:
    with _connect(props, secret_resolver) as conn:
        cur = conn.cursor()
        cur.execute("SELECT USERNAME FROM ALL_USERS ORDER BY USERNAME")
        rows = cur.fetchall() or []
        return [str(r[0]) for r in rows]


def list_tables(props: dict[str, str], secret_resolver, schema: str | None = None) -> list[dict[str, Any]]:
    owner = (schema or "").strip().upper() or None
    query = """
        SELECT OWNER AS SCHEMA, TABLE_NAME AS NAME, 'BASE TABLE' AS TYPE
          FROM ALL_TABLES
        {where_tables}
        UNION ALL
        SELECT OWNER AS SCHEMA, VIEW_NAME AS NAME, 'VIEW' AS TYPE
          FROM ALL_VIEWS
        {where_views}
        ORDER BY 1, 2
    """
    where = "WHERE OWNER = :schema" if owner else ""
    sql = query.format(where_tables=where, where_views=where)
    binds = {"schema": owner} if owner else {}

    with _connect(props, secret_resolver) as conn:
        cur = conn.cursor()
        cur.execute(sql, binds)
        rows = cur.fetchall() or []
        return [{"schema": str(r[0]), "name": str(r[1]), "type": str(r[2])} for r in rows]


def get_table_metadata(props: dict[str, str], secret_resolver, schema: str, table: str) -> dict[str, Any]:
    schema_u = (schema or "").strip().upper()
    table_u = (table or "").strip().upper()
    if not schema_u:
        raise ConnectorError("INVALID_CONFIG", "schema is required.", None)
    if not table_u:
        raise ConnectorError("INVALID_CONFIG", "table is required.", None)

    with _connect(props, secret_resolver) as conn:
        cur = conn.cursor()

        cur.execute(
            """
            SELECT OBJECT_TYPE
              FROM ALL_OBJECTS
             WHERE OWNER = :p_schema
               AND OBJECT_NAME = :p_table
               AND OBJECT_TYPE IN ('TABLE','VIEW')
            """,
            {"p_schema": schema_u, "p_table": table_u},
        )
        row = cur.fetchone()
        if not row:
            raise ConnectorError("INVALID_CONFIG", "Table or view not found.", {"schema": schema_u, "table": table_u})

        object_type = row[0]
        table_type = "VIEW" if object_type == "VIEW" else "BASE TABLE"

        cur.execute(
            """
            SELECT COLUMN_NAME, COLUMN_ID, DATA_TYPE, DATA_LENGTH, DATA_PRECISION, DATA_SCALE, NULLABLE
              FROM ALL_TAB_COLUMNS
             WHERE OWNER = :p_schema
               AND TABLE_NAME = :p_table
             ORDER BY COLUMN_ID
            """,
            {"p_schema": schema_u, "p_table": table_u},
        )
        col_rows = cur.fetchall() or []

        cur.execute(
            """
            SELECT acc.COLUMN_NAME
              FROM ALL_CONSTRAINTS ac
              JOIN ALL_CONS_COLUMNS acc
                ON ac.OWNER = acc.OWNER
               AND ac.CONSTRAINT_NAME = acc.CONSTRAINT_NAME
             WHERE ac.OWNER = :p_schema
               AND ac.TABLE_NAME = :p_table
               AND ac.CONSTRAINT_TYPE = 'P'
            """,
            {"p_schema": schema_u, "p_table": table_u},
        )
        pk_cols = {str(r[0]) for r in (cur.fetchall() or [])}

        columns = []
        for r in col_rows:
            name = str(r[0])
            columns.append(
                {
                    "name": name,
                    "ordinal": int(r[1]) if r[1] is not None else None,
                    "dataType": str(r[2]),
                    "maxLength": int(r[3]) if r[3] is not None else None,
                    "numericPrecision": int(r[4]) if r[4] is not None else None,
                    "numericScale": int(r[5]) if r[5] is not None else None,
                    "isNullable": str(r[6]).upper() == "Y",
                    "isPrimaryKey": name in pk_cols,
                }
            )
        return {"schema": schema_u, "name": table_u, "type": table_type, "columns": columns}

