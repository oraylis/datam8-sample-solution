from __future__ import annotations

from typing import Any


def get_ui_schema() -> dict[str, Any]:
    return {
        "title": "Oracle connection",
        "authModes": [
            {
                "id": "password",
                "label": "Username/Password",
                "fields": [
                    {"key": "auth.mode", "label": "Authentication", "type": "hidden", "required": True, "default": "password"},
                    {"key": "host", "label": "Host", "type": "string", "required": True},
                    {"key": "port", "label": "Port", "type": "number", "required": False, "default": "1521"},
                    {"key": "serviceName", "label": "Service name", "type": "string", "required": True},
                    {"key": "username", "label": "Username", "type": "string", "required": True},
                    {"key": "password", "label": "Password", "type": "secret", "required": True, "secret": True},
                ],
            }
        ],
    }

