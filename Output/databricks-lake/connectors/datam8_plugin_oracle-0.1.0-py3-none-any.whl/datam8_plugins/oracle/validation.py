from __future__ import annotations

from typing import Any


def validate_connection(props: dict[str, str], _secret_resolver: Any) -> list[dict[str, str]]:
    errors: list[dict[str, str]] = []
    if (props.get("auth.mode") or "").strip() not in {"password"}:
        errors.append({"key": "auth.mode", "message": "Unsupported auth.mode.", "level": "error"})
        return errors
    for k in ("host", "serviceName", "username", "password"):
        if not (props.get(k) or "").strip():
            errors.append({"key": k, "message": "Required field is missing.", "level": "error"})
    return errors

