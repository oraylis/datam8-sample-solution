from __future__ import annotations

from typing import Any


def get_ui_schema() -> dict[str, Any]:
    return {
        "title": "SQL Server connection",
        "authModes": [
            {
                "id": "sql_user",
                "label": "Username/Password",
                "fields": [
                    {"key": "auth.mode", "label": "Authentication", "type": "hidden", "required": True, "default": "sql_user"},
                    {"key": "host", "label": "Host", "type": "string", "required": True},
                    {"key": "port", "label": "Port", "type": "number", "required": False, "default": "1433"},
                    {"key": "database", "label": "Database", "type": "string", "required": True},
                    {"key": "username", "label": "Username", "type": "string", "required": True},
                    {"key": "password", "label": "Password", "type": "secret", "required": True, "secret": True},
                    {"key": "encrypt", "label": "Encrypt", "type": "boolean", "required": False, "default": "false"},
                    {"key": "trustServerCertificate", "label": "Trust server certificate", "type": "boolean", "required": False, "default": "true"},
                ],
            }
        ],
    }
