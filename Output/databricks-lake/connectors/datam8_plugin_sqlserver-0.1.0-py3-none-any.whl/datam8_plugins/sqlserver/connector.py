﻿from __future__ import annotations

import os
from typing import Any

from . import metadata
from .ui_schema import get_ui_schema
from .validation import validate_connection

DATA_TYPE_MAPPING = [{'sourceType': 'bigint', 'targetType': 'long'},
 {'sourceType': 'binary', 'targetType': 'string'},
 {'sourceType': 'bit', 'targetType': 'boolean'},
 {'sourceType': 'char', 'targetType': 'string'},
 {'sourceType': 'date', 'targetType': 'datetime'},
 {'sourceType': 'datetime', 'targetType': 'datetime'},
 {'sourceType': 'datetime2', 'targetType': 'datetime'},
 {'sourceType': 'datetimeoffset', 'targetType': 'datetime'},
 {'sourceType': 'decimal', 'targetType': 'decimal'},
 {'sourceType': 'float', 'targetType': 'double'},
 {'sourceType': 'image', 'targetType': 'string'},
 {'sourceType': 'int', 'targetType': 'int'},
 {'sourceType': 'money', 'targetType': 'decimal'},
 {'sourceType': 'nchar', 'targetType': 'string'},
 {'sourceType': 'ntext', 'targetType': 'string'},
 {'sourceType': 'numeric', 'targetType': 'decimal'},
 {'sourceType': 'nvarchar', 'targetType': 'string'},
 {'sourceType': 'real', 'targetType': 'double'},
 {'sourceType': 'smalldatetime', 'targetType': 'datetime'},
 {'sourceType': 'smallint', 'targetType': 'int'},
 {'sourceType': 'smallmoney', 'targetType': 'decimal'},
 {'sourceType': 'text', 'targetType': 'string'},
 {'sourceType': 'time', 'targetType': 'datetime'},
 {'sourceType': 'timestamp', 'targetType': 'string'},
 {'sourceType': 'tinyint', 'targetType': 'int'},
 {'sourceType': 'uniqueidentifier', 'targetType': 'string'},
 {'sourceType': 'varbinary', 'targetType': 'string'},
 {'sourceType': 'varchar', 'targetType': 'string'},
 {'sourceType': 'xml', 'targetType': 'string'},
 {'sourceType': 'sql_variant', 'targetType': 'string'}]


class _NoopSecretResolver:
    def resolve(self, *, key: str, value: str) -> str:
        _ = key
        raw = str(value)
        if raw.startswith("secretRef://"):
            raise RuntimeError(
                "connector_runtime_secret_resolver_required: secretRef value provided but no secret_resolver was supplied",
            )
        return raw


def _as_request_payload(runtime_request: Any) -> dict[str, Any]:
    if runtime_request is None:
        return {}
    if isinstance(runtime_request, str):
        return {"query": runtime_request}
    if isinstance(runtime_request, dict):
        return runtime_request
    raise RuntimeError("connector_runtime_request_invalid: expected str or dict")


def _merge_runtime_properties(extended_properties: dict[str, str], request: dict[str, Any]) -> dict[str, str]:
    merged = dict(extended_properties or {})
    for key in ("properties", "secrets"):
        overrides = request.get(key)
        if not isinstance(overrides, dict):
            continue
        for override_key, override_value in overrides.items():
            if override_value is None:
                continue
            merged[str(override_key)] = str(override_value)
    return merged


def _resolve_query(request: dict[str, Any], props: dict[str, str]) -> str:
    query = str(request.get("query") or request.get("sql") or "").strip()
    if query:
        return query

    table = str(request.get("table") or "").strip()
    schema = str(request.get("schema") or props.get("schema") or "").strip()
    if table:
        if schema and "." not in table:
            table = f"{schema}.{table}"
        return f"SELECT * FROM {table}"

    raise RuntimeError("connector_runtime_query_missing: set request.query or request.table")


def _resolve_fetch_size(request: dict[str, Any]) -> int:
    options = request.get("options") if isinstance(request.get("options"), dict) else {}
    raw = options.get("fetchSize", 5000)
    try:
        size = int(raw)
    except Exception:
        size = 5000
    return size if size > 0 else 5000


def _runtime_options(request: dict[str, Any]) -> dict[str, Any]:
    options = request.get("options")
    if isinstance(options, dict):
        return options
    return {}


def _resolve_connection_method(request: dict[str, Any]) -> str:
    raw = str(_runtime_options(request).get("connectionMethod") or "auto").strip().lower()
    if raw not in {"auto", "native", "jdbc"}:
        raise RuntimeError(f"connector_runtime_connection_method_invalid: unsupported connectionMethod '{raw}'")
    if raw != "auto":
        return raw
    return "jdbc" if (os.environ.get("DATABRICKS_RUNTIME_VERSION") or "").strip() else "native"


def _resolve_secret(secret_resolver: Any, *, key: str, value: str) -> str:
    resolve_fn = getattr(secret_resolver, "resolve", None)
    if callable(resolve_fn):
        return str(resolve_fn(key=key, value=value))
    raise RuntimeError("connector_runtime_secret_resolver_invalid: expected object with resolve()")


def _resolve_jdbc_runtime_options(request: dict[str, Any]) -> tuple[str, str, dict[str, str]]:
    options = _runtime_options(request)
    jdbc = options.get("jdbc")
    if not isinstance(jdbc, dict):
        return "", "", {}
    url = str(jdbc.get("url") or "").strip()
    driver = str(jdbc.get("driver") or "").strip()
    raw_options = jdbc.get("options")
    result: dict[str, str] = {}
    if isinstance(raw_options, dict):
        for key, value in raw_options.items():
            if value is None:
                continue
            result[str(key)] = str(value)
    return url, driver, result


def _build_sqlserver_jdbc_url(props: dict[str, str], request: dict[str, Any]) -> tuple[str, str, dict[str, str]]:
    runtime_url, runtime_driver, runtime_options = _resolve_jdbc_runtime_options(request)
    if runtime_url:
        return runtime_url, runtime_driver, runtime_options

    host_raw = (props.get("host") or "").strip()
    port = metadata._as_int(props, "port", 1433)
    host, port = metadata._sanitize_server_and_port(host_raw, port)
    database = (props.get("database") or "").strip()
    if not database:
        raise RuntimeError("connector_runtime_source_missing: database is required for jdbc mode")

    encrypt = metadata._truthy(props.get("encrypt") if props.get("encrypt") is not None else "false")
    trust = metadata._truthy(props.get("trustServerCertificate") if props.get("trustServerCertificate") is not None else "true")
    url = (
        f"jdbc:sqlserver://{host}:{port};"
        f"databaseName={database};"
        f"encrypt={'true' if encrypt else 'false'};"
        f"trustServerCertificate={'true' if trust else 'false'}"
    )
    return url, runtime_driver, runtime_options


def _rows_to_dataframe(spark: Any, columns: list[str], rows: list[tuple[Any, ...]]) -> Any:
    if rows:
        if columns:
            return spark.createDataFrame(rows, schema=columns)
        return spark.createDataFrame(rows)

    from pyspark.sql.types import StringType, StructField, StructType  # type: ignore

    schema = StructType([StructField(col, StringType(), True) for col in columns])
    return spark.createDataFrame([], schema=schema)


class Connector:
    @staticmethod
    def get_manifest() -> dict[str, Any]:
        return {
            "id": "sqlserver",
            "displayName": "SQL Server",
            "version": "0.1.0",
            "manifestVersion": 1,
            "capabilities": {
                "uiSchema": True,
                "validateConnection": True,
                "metadata": {"listTables": True, "getTableMetadata": True},
                "runtimeQuery": {"sql": False, "dataFrame": True},
            },
            "dataTypeMapping": DATA_TYPE_MAPPING,
        }

    @staticmethod
    def get_ui_schema() -> dict[str, Any]:
        return get_ui_schema()

    @staticmethod
    def validate_connection(extended_properties: dict[str, str], secret_resolver) -> list[dict[str, str]]:
        return validate_connection(extended_properties, secret_resolver)

    @staticmethod
    def test_connection(extended_properties: dict[str, str], secret_resolver) -> None:
        return metadata.test_connection(extended_properties, secret_resolver)

    @staticmethod
    def list_schemas(extended_properties: dict[str, str], secret_resolver) -> list[str]:
        return metadata.list_schemas(extended_properties, secret_resolver)

    @staticmethod
    def list_tables(extended_properties: dict[str, str], secret_resolver, schema: str | None = None) -> list[dict[str, Any]]:
        return metadata.list_tables(extended_properties, secret_resolver, schema=schema)

    @staticmethod
    def get_table_metadata(extended_properties: dict[str, str], secret_resolver, schema: str, table: str) -> dict[str, Any]:
        return metadata.get_table_metadata(extended_properties, secret_resolver, schema, table)

    @staticmethod
    def extract_data(
        extended_properties: dict[str, str],
        runtime_request: Any = None,
    ) -> Any:
        from pyspark.sql import SparkSession  # type: ignore
        spark = SparkSession.builder.getOrCreate()
        request = _as_request_payload(runtime_request)
        resolver = _NoopSecretResolver()
        effective_props = _merge_runtime_properties(extended_properties, request)
        query = _resolve_query(request, effective_props)
        fetch_size = _resolve_fetch_size(request)
        method = _resolve_connection_method(request)

        if method == "jdbc":
            username = (effective_props.get("username") or "").strip()
            if not username:
                raise RuntimeError("connector_runtime_source_missing: username is required for jdbc mode")
            password = _resolve_secret(resolver, key="password", value=effective_props.get("password") or "")
            url, driver, jdbc_options = _build_sqlserver_jdbc_url(effective_props, request)
            reader = (
                spark.read.format("jdbc")
                .option("url", url)
                .option("query", query)
                .option("user", username)
                .option("password", password)
                .option("fetchsize", str(fetch_size))
            )
            if driver:
                reader = reader.option("driver", driver)
            for key, value in jdbc_options.items():
                reader = reader.option(str(key), str(value))
            return reader.load()

        conn = metadata._connect(effective_props, resolver)
        try:
            cur = conn.cursor()
            cur.execute(query)
            desc = cur.description or []
            columns: list[str] = []
            for idx, col in enumerate(desc):
                if isinstance(col, (tuple, list)) and col:
                    name = col[0]
                else:
                    name = getattr(col, "name", None)
                columns.append(str(name) if name else f"col_{idx + 1}")
            rows: list[tuple[Any, ...]] = []
            while True:
                batch = cur.fetchmany(fetch_size)
                if not batch:
                    break
                rows.extend(batch)
            return _rows_to_dataframe(spark, columns, rows)
        finally:
            try:
                conn.close()
            except Exception:
                pass
