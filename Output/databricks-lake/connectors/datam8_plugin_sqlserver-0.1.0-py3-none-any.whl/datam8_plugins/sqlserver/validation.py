from __future__ import annotations

from typing import Any


def _truthy(v: str) -> bool:
    return (v or "").strip().lower() in {"1", "true", "yes", "y", "on"}


def validate_connection(props: dict[str, str], _secret_resolver: Any) -> list[dict[str, str]]:
    errors: list[dict[str, str]] = []
    if (props.get("auth.mode") or "").strip() not in {"sql_user"}:
        errors.append({"key": "auth.mode", "message": "Unsupported auth.mode.", "level": "error"})
        return errors
    for k in ("host", "database", "username", "password"):
        if not (props.get(k) or "").strip():
            errors.append({"key": k, "message": "Required field is missing.", "level": "error"})
    # bool fields are strings in extendedProperties
    for b in ("encrypt", "trustServerCertificate"):
        v = props.get(b)
        if v is None or v == "":
            continue
        _ = _truthy(v)
    return errors

