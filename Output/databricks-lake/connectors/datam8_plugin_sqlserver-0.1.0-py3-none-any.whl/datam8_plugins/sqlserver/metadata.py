from __future__ import annotations

from typing import Any


class ConnectorError(Exception):
    def __init__(self, code: str, message: str, details: dict[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details


def _truthy(v: Any) -> bool:
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return v != 0
    if isinstance(v, str):
        return v.strip().lower() in {"1", "true", "yes", "y", "on"}
    return False


def _as_int(props: dict[str, str], key: str, default: int) -> int:
    raw = (props.get(key) or "").strip()
    if not raw:
        return default
    try:
        return int(raw)
    except Exception:
        raise ConnectorError("INVALID_CONFIG", f"Invalid number for {key}.", {"key": key})


def _sanitize_server_and_port(server: str, port: int) -> tuple[str, int]:
    s = (server or "").strip()
    if s.lower().startswith("tcp:"):
        s = s[4:].strip()
    s = s.rstrip(" ,;")

    if "," in s:
        host_part, port_part = s.rsplit(",", 1)
        host_part = host_part.strip().rstrip(" ,;")
        port_part = port_part.strip()
        if host_part and port_part.isdigit():
            maybe_port = int(port_part)
            if port <= 0 or port == 1433:
                port = maybe_port
            s = host_part

    if ":" in s and s.count(":") == 1:
        host_part, port_part = s.split(":", 1)
        host_part = host_part.strip().rstrip(" ,;")
        port_part = port_part.strip()
        if host_part and port_part.isdigit():
            maybe_port = int(port_part)
            if port <= 0 or port == 1433:
                port = maybe_port
            s = host_part

    s = s.strip().rstrip(" ,;")
    if not s:
        raise ConnectorError("INVALID_CONFIG", "Missing host.", None)
    if port <= 0:
        raise ConnectorError("INVALID_CONFIG", "Invalid port.", {"port": port})
    return s, port


def _connect(props: dict[str, str], secret_resolver):
    host = (props.get("host") or "").strip()
    database = (props.get("database") or "").strip()
    username = (props.get("username") or "").strip()
    password = secret_resolver.resolve(key="password", value=props.get("password") or "")
    port = _as_int(props, "port", 1433)
    encrypt = _truthy(props.get("encrypt") if props.get("encrypt") is not None else "false")
    trust = _truthy(props.get("trustServerCertificate") if props.get("trustServerCertificate") is not None else "true")

    host, port = _sanitize_server_and_port(host, port)
    if not database or not username or not password:
        raise ConnectorError("INVALID_CONFIG", "Missing required fields.", None)

    try:
        import pytds  # type: ignore
    except Exception as e:
        raise ConnectorError(
            "MISSING_DEPENDENCY",
            "SQL Server connector dependency is missing (python-tds).",
            {"error": str(e)},
        )

    import certifi

    def _connect_once(*, use_encrypt: bool):
        cafile = None
        enc_login_only = True
        if use_encrypt:
            cafile = __import__("os").environ.get("DATAM8_SQLSERVER_CAFILE") or certifi.where()
            enc_login_only = False

        return pytds.connect(
            dsn=host,
            port=port,
            database=database,
            user=username,
            password=password,
            timeout=10.0,
            login_timeout=10.0,
            autocommit=True,
            cafile=cafile,
            validate_host=not trust,
            enc_login_only=enc_login_only,
        )

    try:
        return _connect_once(use_encrypt=encrypt)
    except Exception as e:
        msg = str(e).lower()
        if encrypt and trust and "pyopenssl" in msg:
            try:
                return _connect_once(use_encrypt=False)
            except Exception as fallback_error:
                raise ConnectorError(
                    "MISSING_DEPENDENCY",
                    "SQL Server encryption requires pyOpenSSL. Disable Encrypt or install a compatible pyOpenSSL stack.",
                    {"error": str(e), "fallbackError": str(fallback_error)},
                )
        if "pyopenssl" in msg:
            raise ConnectorError(
                "MISSING_DEPENDENCY",
                "SQL Server connector dependency is missing or broken (pyOpenSSL).",
                {"error": str(e)},
            )
        if "login failed" in msg or "authentication" in msg or "denied" in msg:
            raise ConnectorError("AUTH_FAILED", "Authentication failed.", {"error": str(e)})
        raise ConnectorError("NETWORK", "SQL Server connection failed.", {"error": str(e)})


def test_connection(props: dict[str, str], secret_resolver) -> None:
    with _connect(props, secret_resolver) as conn:
        cur = conn.cursor()
        cur.execute("SELECT 1")
        _ = cur.fetchone()


def list_schemas(props: dict[str, str], secret_resolver) -> list[str]:
    with _connect(props, secret_resolver) as conn:
        cur = conn.cursor()
        cur.execute("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA ORDER BY SCHEMA_NAME")
        return [str(r[0]) for r in (cur.fetchall() or [])]


def list_tables(props: dict[str, str], secret_resolver, schema: str | None = None) -> list[dict[str, Any]]:
    schema_filter = (schema or "").strip() or None
    with _connect(props, secret_resolver) as conn:
        cur = conn.cursor()
        if schema_filter:
            cur.execute(
                """SELECT TABLE_SCHEMA, TABLE_NAME, TABLE_TYPE
                   FROM INFORMATION_SCHEMA.TABLES
                   WHERE TABLE_SCHEMA=%s AND TABLE_TYPE IN ('BASE TABLE','VIEW')
                   ORDER BY TABLE_SCHEMA, TABLE_NAME""",
                (schema_filter,),
            )
        else:
            cur.execute(
                """SELECT TABLE_SCHEMA, TABLE_NAME, TABLE_TYPE
                   FROM INFORMATION_SCHEMA.TABLES
                   WHERE TABLE_TYPE IN ('BASE TABLE','VIEW')
                   ORDER BY TABLE_SCHEMA, TABLE_NAME"""
            )
        rows = cur.fetchall() or []
        return [{"schema": str(r[0]), "name": str(r[1]), "type": str(r[2])} for r in rows]


def get_table_metadata(props: dict[str, str], secret_resolver, schema: str, table: str) -> dict[str, Any]:
    effective_schema = (schema or "").strip() or "dbo"
    effective_table = (table or "").strip()
    if not effective_table:
        raise ConnectorError("INVALID_CONFIG", "table is required.", None)
    with _connect(props, secret_resolver) as conn:
        cur = conn.cursor()
        cur.execute(
            """SELECT TABLE_TYPE FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=%s AND TABLE_NAME=%s""",
            (effective_schema, effective_table),
        )
        row = cur.fetchone()
        if not row:
            raise ConnectorError("INVALID_CONFIG", "Table not found.", {"schema": effective_schema, "table": effective_table})
        table_type = row[0]

        cur.execute(
            """SELECT COLUMN_NAME, ORDINAL_POSITION, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH,
                      NUMERIC_PRECISION, NUMERIC_SCALE, IS_NULLABLE
               FROM INFORMATION_SCHEMA.COLUMNS
               WHERE TABLE_SCHEMA=%s AND TABLE_NAME=%s
               ORDER BY ORDINAL_POSITION""",
            (effective_schema, effective_table),
        )
        cols = cur.fetchall() or []

        cur.execute(
            """SELECT kcu.COLUMN_NAME
               FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
               JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE kcu
                 ON tc.CONSTRAINT_NAME = kcu.CONSTRAINT_NAME
                AND tc.TABLE_SCHEMA = kcu.TABLE_SCHEMA
              WHERE tc.CONSTRAINT_TYPE = 'PRIMARY KEY'
                AND tc.TABLE_SCHEMA=%s AND tc.TABLE_NAME=%s""",
            (effective_schema, effective_table),
        )
        pk_cols = {str(r[0]) for r in (cur.fetchall() or [])}

        columns = []
        for c in cols:
            name = str(c[0])
            columns.append(
                {
                    "name": name,
                    "ordinal": int(c[1]),
                    "dataType": str(c[2]),
                    "maxLength": int(c[3]) if c[3] is not None else None,
                    "numericPrecision": int(c[4]) if c[4] is not None else None,
                    "numericScale": int(c[5]) if c[5] is not None else None,
                    "isNullable": str(c[6]).upper() == "YES",
                    "isPrimaryKey": name in pk_cols,
                }
            )
        return {"schema": effective_schema, "name": effective_table, "type": str(table_type), "columns": columns}
