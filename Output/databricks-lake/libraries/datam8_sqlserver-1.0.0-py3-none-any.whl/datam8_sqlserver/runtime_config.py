REQUIRED = ["authMode", "host", "database", "port", "username", "password"]


def normalize(config):
    if not isinstance(config, dict):
        raise ValueError("Runtime config must be dict")
    auth_mode = config.get("authMode")
    if auth_mode == "windows":
        raise ValueError(
            "SQL Server authMode=windows is not supported in Spark JDBC runtime; use sql_user"
        )
    missing = [key for key in REQUIRED if config.get(key) in (None, "")]
    if missing:
        raise ValueError(f"Missing required runtime config keys: {missing}")
    normalized = dict(config)
    normalized.setdefault("dialect", "sqlserver")
    return normalized
