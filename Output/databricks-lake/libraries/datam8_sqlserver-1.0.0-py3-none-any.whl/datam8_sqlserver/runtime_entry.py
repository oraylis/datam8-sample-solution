from .runtime_config import normalize
from .extract_data import extract_data as _extract
def extract_data(config, **kwargs):
    return _extract(normalize(config), **kwargs)
