from __future__ import annotations

try:
    from pyspark.sql import SparkSession
except Exception:  # pragma: no cover
    SparkSession = None


def _spark_session():
    if SparkSession is None:
        raise RuntimeError("PySpark is required for SQL runtime extraction")
    spark = SparkSession.getActiveSession() or SparkSession.builder.getOrCreate()
    if spark is None:
        raise RuntimeError("Active Spark session is required for SQL runtime extraction")
    return spark


def _jdbc_url(config: dict) -> str:
    def _as_bool(value, default: bool) -> bool:
        if value is None:
            return default
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() in ("1", "true", "yes", "y", "on")

    host = config.get("host")
    port = int(config.get("port"))
    database = config.get("database")
    encrypt = str(_as_bool(config.get("encrypt", True), True)).lower()
    trust = str(_as_bool(config.get("trust_server_certificate", False), False)).lower()
    return (
        f"jdbc:sqlserver://{host}:{port};databaseName={database};"
        f"encrypt={encrypt};trustServerCertificate={trust}"
    )


def extract_data(config: dict, query: str, limit: int | None = None):
    spark = _spark_session()
    reader = (
        spark.read.format("jdbc")
        .option("url", _jdbc_url(config))
        .option("dbtable", f"({query}) q")
        .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
        .option("user", config["username"])
        .option("password", config["password"])
    )
    df = reader.load()
    if limit is not None:
        df = df.limit(int(limit))
    return df
